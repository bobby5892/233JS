// inside general.js file
console.log('General JS File');
import "../../node_modules/bootstrap/less/bootstrap.less";
import '../css/styles.css';
import 'bootstrap';
