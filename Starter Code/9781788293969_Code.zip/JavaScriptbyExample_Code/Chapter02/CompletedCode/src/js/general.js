import "../../node_modules/bootstrap/less/bootstrap.less";
import '../css/styles.css';

import 'bootstrap';

console.log('General JS File');
