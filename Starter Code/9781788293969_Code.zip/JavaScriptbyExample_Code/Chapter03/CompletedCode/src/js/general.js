/**
 * CSS files
 */
import "../../node_modules/bootstrap/less/bootstrap.less";
import '../css/styles.css';

/**
 * Bootstrap JS File
 */
import 'bootstrap';
