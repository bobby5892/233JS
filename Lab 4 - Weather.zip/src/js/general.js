import "../../node_modules/bootstrap/less/bootstrap.less";
import '../css/styles.scss';
import 'bootstrap';

console.log('General JS File');
